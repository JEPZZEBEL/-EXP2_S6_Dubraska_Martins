import java.util.Scanner;

public class TeatroMoro {
    // Variables estáticas para contabilizar estadísticas globales
    static int totalIngresos = 0;
    static int cantidadEntradasVendidas = 0;
    static int numeroDeEntradasDisponibles = 50; // Se inicializa con el número de entradas disponibles
    static boolean[] asientosDisponibles = new boolean[numeroDeEntradasDisponibles]; // Variable para almacenar la disponibilidad de los asientos
    static String nombreDelTeatro = "Teatro Moro";
    static int capacidadDeLaSala = 50;
    static double precioEntradaVIP = 200000;
    static double precioEntradaPlatea = 150000;
    static double precioEntradaGeneral = 80000;

    public static void main(String[] args) {
        // Inicializar todos los asientos como disponibles al inicio
        for (int i = 0; i < numeroDeEntradasDisponibles; i++) {
            asientosDisponibles[i] = true;
        }

        try (Scanner scanner = new Scanner(System.in)) {
            int opcion;

            // Paso 1: Menú de Venta
            do {
                mostrarMenu();
                opcion = scanner.nextInt();

                switch (opcion) {
                    case 1 -> ventaEntradas(scanner); // A) Manejo de Entradas
                    case 2 -> imprimirBoleta(); // B) Generación de Boletas
                    case 3 -> System.out.println("Gracias por comprar en Teatro Moro.");
                    default -> System.out.println("Opcion invalida. Por favor, seleccione una opcion valida.");
                }
            } while (opcion != 3);
        }
    }

       public static void mostrarMenu() {
        System.out.println("=== MENU ===");
        System.out.println("1. Comprar entradas");
        System.out.println("2. Imprimir boleta");
        System.out.println("3. Salir");
        System.out.print("Seleccione una opcion: ");
    }
    public static void ventaEntradas(Scanner scanner) {
        // Variables locales para almacenar temporalmente datos
        String tipoEntrada;
        int precioBase;
        int precioFinal;
        int descuento = 0;
        int asientoSeleccionado;

        // Solicitar ubicación de entrada
        System.out.print("Ingrese la ubicacion de la entrada (VIP, Platea, General): ");
        tipoEntrada = scanner.next();

        // Mostrar disponibilidad de asientos
        mostrarDisponibilidadAsientos();

        // Solicitar selección de asiento
        System.out.print("Seleccione el numero de asiento: ");
        asientoSeleccionado = scanner.nextInt();

        // Verificar disponibilidad de asiento
        if (asientoSeleccionado < 1 || asientoSeleccionado > numeroDeEntradasDisponibles || !esAsientoDisponible(asientoSeleccionado)) {
            System.out.println("El asiento seleccionado no esta disponible.");
            return;
        }

        // Verificar descuentos
        System.out.print(" Es estudiante? (si/no): ");
        String respuestaEstudiante = scanner.next();
        if (respuestaEstudiante.equalsIgnoreCase("si")) {
            descuento = 10;
        } else {
            System.out.print(" Es de la tercera edad? (si/no): ");
            String respuestaTerceraEdad = scanner.next();
            if (respuestaTerceraEdad.equalsIgnoreCase("si")) {
                descuento = 15;
            }
        }

        // Calcular precio final
        precioBase = calcularPrecioBase(tipoEntrada);
        precioFinal = (int) (precioBase - (precioBase * descuento / 100));

        // Mostrar precio final
        System.out.println("El precio final de la entrada es: $" + precioFinal);

        // Actualizar variables globales
        totalIngresos += precioFinal;
        cantidadEntradasVendidas++;
        numeroDeEntradasDisponibles--;
        marcarAsientoNoDisponible(asientoSeleccionado);

        // Mostrar información sobre la venta
        System.out.println("Entrada vendida. Total de ingresos: $" + totalIngresos +
                ", Entradas disponibles: " + numeroDeEntradasDisponibles);

        // Información de la compra
        System.out.println("=== DETALLE DE LA ENTRADA ===");
        System.out.println("Tipo de entrada: " + tipoEntrada);
        System.out.println("Cantidad: 1");
        System.out.println("Asiento: " + asientoSeleccionado);
        if (descuento > 0) {
            System.out.println("Descuento aplicado: " + descuento + "%");
        } else {
            System.out.println("Sin descuento aplicado");
        }
    }

    public static int calcularPrecioBase(String tipoEntrada) {
        return switch (tipoEntrada.toLowerCase()) {
            case "vip" -> (int) precioEntradaVIP;
            case "platea" -> (int) precioEntradaPlatea;
            case "general" -> (int) precioEntradaGeneral;
            default -> 0;
        };
    }

    //Generación de Boletas
    public static void imprimirBoleta() {
        if (cantidadEntradasVendidas > 0) {
            System.out.println("=== ÚLTIMA COMPRA REALIZADA ===");
            System.out.println("Cantidad de entradas vendidas: " + cantidadEntradasVendidas);
            System.out.println("Total de ingresos: $" + totalIngresos);
        } else {
            System.out.println("Aun no se ha realizado ninguna compra.");
        }
    }

    // Método para mostrar la disponibilidad de asientos
    public static void mostrarDisponibilidadAsientos() {
        System.out.println("=== DISPONIBILIDAD DE ASIENTOS ===");
        for (int i = 0; i < numeroDeEntradasDisponibles; i++) {
            System.out.print("Asiento " + (i + 1) + ": ");
            if (esAsientoDisponible(i + 1)) {
                System.out.println("Disponible");
            } else {
                System.out.println("No disponible");
            }
        }
    }

    // Método para verificar si un asiento está disponible
    public static boolean esAsientoDisponible(int asientoSeleccionado) {
        return asientosDisponibles[asientoSeleccionado - 1];
    }

    // Método para marcar un asiento como no disponible
    public static void marcarAsientoNoDisponible(int asientoSeleccionado) {
        asientosDisponibles[asientoSeleccionado - 1] = false;
    }
}
